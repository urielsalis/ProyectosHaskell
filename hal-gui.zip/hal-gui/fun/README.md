fun [![Build Status](https://travis-ci.org/alexgadea/fun.png?branch=master)](https://travis-ci.org/alexgadea/fun)
===

Derivador de programas a partir de especificaciones.
