equ
===

equ es un chequeador de demostraciones para una lógica ecuacional. El
primer prototipo de equ fue [yahc](https://cs.famaf.unc.edu.ar/~mpagano/yahc/ "página de yahc").


[![Build Status](https://travis-ci.org/miguelpagano/equ.png?branch=master)](https://travis-ci.org/miguelpagano/equ)
