hal [![Build Status](https://travis-ci.org/alexgadea/hal.png?branch=master)](https://travis-ci.org/alexgadea/hal)
===

Verificador de programas imperativos.
