hal-gui [![Build Status](https://travis-ci.org/alexgadea/hal-gui.png?branch=master)](https://travis-ci.org/alexgadea/hal-gui)
=======

hal-gui es la interfaz grafica para hal.
