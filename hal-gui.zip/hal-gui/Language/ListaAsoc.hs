module Language.ListaAsoc where

data ListaAsoc a b = Vacia
                   | Nodo a b (ListaAsoc a b)
                   
				   
-- Devuelve la cantidad de "datos" en una lista				   
la_long :: Integral c => ListaAsoc a b -> c
la_long = undefined


-- Transforma una lista de asociaciones en una lista de pares (clave, dato)
la_pares :: ListaAsoc a b -> [(a,b)]
la_pares = undefined


-- Dada una lista y una clave devuelve el dato asociado, si es que existe. En caso contrario devuelve Nothing.
la_buscar :: Eq a => ListaAsoc a b -> a -> Maybe b
la_buscar = undefined


-- Verifica si una clave existe en una lista
la_existe :: Eq a => ListaAsoc a b -> a -> Bool
la_existe = undefined


-- Dada una lista, agrega una clave con su valor asociado "d" en la lista si la clave NO existe. En caso de que la clave exista, reemplaza el dato con el nuevo dato "d".
la_agregar :: Eq a => a -> b -> ListaAsoc a b -> ListaAsoc a b
la_agregar = undefined


-- Dada una clave, elimina el dato asociado en la lista.
la_borrar :: Eq a => a -> ListaAsoc a b -> ListaAsoc a b
la_borrar = undefined





